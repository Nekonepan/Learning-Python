import random

def argmax_random_tie(seq, key=lambda x: x):
    max_value = max(map(key, seq))
    max_items = [item for item in seq if key(item) == max_value]
    return random.choice(max_items)
