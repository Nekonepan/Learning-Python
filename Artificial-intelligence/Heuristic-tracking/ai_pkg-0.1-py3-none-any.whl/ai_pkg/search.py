class Graph:
    def __init__(self, graph_dict=None, directed=True):
        self.graph_dict = graph_dict or {}
        self.directed = directed

class Node:
    def __init__(self, state):
        self.state = state

class Problem:
    def __init__(self, initial):
        self.initial = initial
